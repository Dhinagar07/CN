#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <pthread.h>

void* handle_client(void* connfd_ptr) {
    int connfd = *(int*)connfd_ptr;
    free(connfd_ptr);
    char buffer[10];
    
    while (1) {
        memset(buffer, 0, sizeof(buffer));
        int n = read(connfd, buffer, sizeof(buffer));
        if (n <= 0) {
            printf("\nClient disconnected.\n");
            break;
        }
        printf("The message from the client is: %s", buffer);
        write(connfd, buffer, sizeof(buffer));
    }
    
    close(connfd);
    return NULL;
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <IP address> <port>\n", argv[0]);
        return -1;
    }

    int port = atoi(argv[2]);
    int sockdesc = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in servaddr, cliaddr;

    if (sockdesc < 0) {
        perror("Failed to create socket");
        return -1;
    }

    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(port);
    servaddr.sin_addr.s_addr = inet_addr(argv[1]);

    if (bind(sockdesc, (struct sockaddr*)&servaddr, sizeof(servaddr)) < 0) {
        perror("Bind failed");
        close(sockdesc);
        return -1;
    }

    if (listen(sockdesc, 5) < 0) {
        perror("Listen failed");
        close(sockdesc);
        return -1;
    }

    while (1) {
        int len = sizeof(cliaddr);
        int* connfd_ptr = malloc(sizeof(int));
        *connfd_ptr = accept(sockdesc, (struct sockaddr*)&cliaddr, &len);

        if (*connfd_ptr < 0) {
            perror("Accept failed");
            free(connfd_ptr);
            continue;
        }

        pthread_t tid;
        pthread_create(&tid, NULL, handle_client, connfd_ptr);
        pthread_detach(tid);
    }

    close(sockdesc);
    return 0;
}
