#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<netinet/in.h>

int main()
{
    int sockdesc = socket(AF_INET,SOCK_STREAM,0);
    struct sockaddr_in servaddr,cliaddr;
    if(sockdesc < 0)
    {
        printf("\nFailed to create socket");
        return -1;
    }
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(3536);
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    if(bind(sockdesc,(struct sockaddr*)&servaddr,sizeof(servaddr)) < 0)
    {
        printf("\nBind failed");
        return -1;
    }
    if(listen(sockdesc,5) < 0)
    {
        printf("\nListen failed");
        return -1;
    }
    while(1)
    {
        int len = sizeof(cliaddr);
        int connfd = accept(sockdesc,(struct sockaddr*)&cliaddr,&len);
        if(connfd < 0)
        {
            printf("Accept failed");
            return -1;
        }
        char buffer[10];
        strcpy(buffer,"");
        read(connfd,buffer,10);
        printf("The message from the server is : %s",buffer);
        write(connfd,buffer,sizeof(buffer));
    }
    close(sockdesc);
    return 0;
}