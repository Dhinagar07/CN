#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<string.h>
#include<netinet/in.h>
#include<unistd.h>

int main()
{
    int sockfd = socket(AF_INET,SOCK_STREAM,0);
    struct sockaddr_in servaddr;
    if(sockfd < 0)
    {
        printf("\nFailed to create socket");
        return -1;
    }
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(3536);
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);

    int connfd = connect(sockdesc,(struct sockaddr*)& servaddr,sizeof(servaddr));
    if(connfd < 0)
    {
        printf("\nThe connection failed");
        return -1;
    }
    char buffer[10];
    fgets(buffer,sizeof(buffer),stdin);
    write(sockdesc,buffer,sizeof(buffer));
    read(sockdesc,buffer,sizeof(buffer));
    printf("\nMessage from the server is %s",buffer);
    close(sockdesc);
    return 0;
}