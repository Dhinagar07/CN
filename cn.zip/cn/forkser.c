#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/wait.h>
#include <signal.h>

void handle_client(int connfd) {
    char buffer[10];

    while (1) {
        memset(buffer, 0, sizeof(buffer));
        int n = read(connfd, buffer, sizeof(buffer));
        if (n <= 0) {
            printf("\nClient disconnected.\n");
            break;
        }
        printf("The message from the client is: %s", buffer);
        write(connfd, buffer, sizeof(buffer));
    }

    close(connfd);
}

void sigchld_handler(int signo) {
    while (waitpid(-1, NULL, WNOHANG) > 0);
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <IP address> <port>\n", argv[0]);
        return -1;
    }

    int port = atoi(argv[2]);
    int sockdesc = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in servaddr, cliaddr;

    if (sockdesc < 0) {
        perror("Failed to create socket");
        return -1;
    }

    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(port);
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);

    if (bind(sockdesc, (struct sockaddr*)&servaddr, sizeof(servaddr)) < 0) {
        perror("Bind failed");
        close(sockdesc);
        return -1;
    }

    if (listen(sockdesc, 5) < 0) {
        perror("Listen failed");
        close(sockdesc);
        return -1;
    }

    signal(SIGCHLD, sigchld_handler);

    while (1) {
        int len = sizeof(cliaddr);
        int connfd = accept(sockdesc, (struct sockaddr*)&cliaddr, &len);

        if (connfd < 0) {
            perror("Accept failed");
            continue;
        }

        pid_t pid = fork();
        if (pid == 0) {
            close(sockdesc);
            handle_client(connfd);
            exit(0);
        } else if (pid > 0) {
            close(connfd);
        } else {
            perror("Fork failed");
        }
    }

    close(sockdesc);
    return 0;
}
