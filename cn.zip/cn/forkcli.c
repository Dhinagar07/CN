#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <string.h>
#include <netinet/in.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <IP address> <port>\n", argv[0]);
        return -1;
    }

    int port = atoi(argv[2]);
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in servaddr;

    if (sockfd < 0) {
        perror("Failed to create socket");
        return -1;
    }

    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(port);

    // Convert IP address from string to binary form
    if (inet_pton(AF_INET, argv[1], &servaddr.sin_addr) <= 0) {
        perror("Invalid address/ Address not supported");
        close(sockfd);
        return -1;
    }

    if (connect(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr)) < 0) {
        perror("Connection failed");
        close(sockfd);
        return -1;
    }

    char buffer[10];
    while (1) {
        printf("Enter message: ");
        fgets(buffer, sizeof(buffer), stdin);
        write(sockfd, buffer, sizeof(buffer));
        read(sockfd, buffer, sizeof(buffer));
        printf("\nMessage from the server is: %s", buffer);
    }

    close(sockfd);
    return 0;
}
