#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>

typedef struct {
    char method[8];
    char path[256];
    char version[16];
    char host[128];
    char headers[1024];
    char body[2048];
} HttpRequest;

typedef struct {
    char version[16];
    int status_code;
    char status_message[64];
    char headers[1024];
    char body[2048];
} HttpResponse;

#define BUFFER_SIZE 1024

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <port>\n", argv[0]);
        return -1;
    }

    int port = atoi(argv[1]);

    int server_fd, new_socket;
    struct sockaddr_in address;
    int addrlen = sizeof(address);
    HttpRequest request;
    HttpResponse response;

    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("Socket failed");
        exit(EXIT_FAILURE);
    }

    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(port);

    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("Bind failed");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    if (listen(server_fd, 3) < 0) {
        perror("Listen failed");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    printf("Server listening on port %d\n", port);

    if ((new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t *)&addrlen)) < 0) {
        perror("Accept failed");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    recv(new_socket, &request, sizeof(HttpRequest), 0);
    printf("Received request: %s %s %s\n", request.method, request.path, request.version);

    strcpy(response.version, "HTTP/1.1");
    response.status_code = 200;
    strcpy(response.status_message, "OK");
    strcpy(response.headers, "Content-Type: text/plain");
    strcpy(response.body, "Hello, world!");

    send(new_socket, &response, sizeof(HttpResponse), 0);

    close(new_socket);
    close(server_fd);
    return 0;
}

