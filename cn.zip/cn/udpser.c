#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <errno.h>

int main() {
    int sockdesc = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockdesc < 0) {
        perror("Socket creation failed");
        return -1;
    }

    struct sockaddr_in servaddr, cliaddr;
    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(3536);
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);

    if (bind(sockdesc, (struct sockaddr*)&servaddr, sizeof(servaddr)) < 0) {
        perror("Bind failed");
        close(sockdesc);
        return -1;
    }

    while (1) {
        int len = sizeof(cliaddr);
        char buffer[1024] = {0}; // Increased buffer size

        printf("\nWaiting for request...\n");
        ssize_t recv_len = recvfrom(sockdesc, buffer, sizeof(buffer) - 1, 0, (struct sockaddr*)&cliaddr, &len);
        if (recv_len < 0) {
            perror("Receive failed");
            continue;
        }

        buffer[recv_len] = '\0'; // Null-terminate the received string
        printf("The message from the client: %s\n", buffer);

        ssize_t sent_len = sendto(sockdesc, buffer, recv_len, 0, (struct sockaddr*)&cliaddr, len);
        if (sent_len < 0) {
            perror("Send failed");
        }
    }

    close(sockdesc);
    return 0;
}

