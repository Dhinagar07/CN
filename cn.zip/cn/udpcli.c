#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <string.h>
#include <errno.h>

#define BUFFER_SIZE 1024

int main() {
    int sockdesc = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockdesc < 0) {
        perror("Failed to create socket");
        return -1;
    }

    struct sockaddr_in servaddr;
    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(3536);
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY); // Change to server IP

    char buffer[BUFFER_SIZE];
    
    printf("Enter message to send: ");
    if (fgets(buffer, sizeof(buffer), stdin) == NULL) {
        perror("Error reading input");
        close(sockdesc);
        return -1;
    }

    // Remove the newline character if present
    buffer[strcspn(buffer, "\n")] = '\0';

    ssize_t sent_len = sendto(sockdesc, buffer, strlen(buffer), 0, (struct sockaddr*)&servaddr, sizeof(servaddr));
    if (sent_len < 0) {
        perror("Send failed");
        close(sockdesc);
        return -1;
    }

    printf("Message sent to server. Waiting for response...\n");

    struct sockaddr_in response_addr;
    socklen_t addr_len = sizeof(response_addr);
    ssize_t recv_len = recvfrom(sockdesc, buffer, sizeof(buffer) - 1, 0, (struct sockaddr*)&response_addr, &addr_len);
    if (recv_len < 0) {
        perror("Receive failed");
        close(sockdesc);
        return -1;
    }
    
    buffer[recv_len] = '\0'; // Null-terminate the received string
    printf("The message from the server is: %s\n", buffer);

    close(sockdesc);
    return 0;
}

