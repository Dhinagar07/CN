#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <string.h>
#include <netinet/in.h>
#include <unistd.h>
#include <fcntl.h>

#define BUFFER_SIZE 1024

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <server IP> <server port>\n", argv[0]);
        return -1;
    }

    const char *server_ip = argv[1];
    int server_port = atoi(argv[2]);

    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("Failed to create socket");
        return -1;
    }

    struct sockaddr_in servaddr;
    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(server_port);
    if (inet_pton(AF_INET, server_ip, &servaddr.sin_addr) <= 0) {
        perror("Invalid address/ Address not supported");
        close(sockfd);
        return -1;
    }

    if (connect(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr)) < 0) {
        perror("Connection failed");
        close(sockfd);
        return -1;
    }

    char filename[BUFFER_SIZE];
    printf("Enter the filename to download: ");
    fgets(filename, BUFFER_SIZE, stdin);

    filename[strcspn(filename, "\n")] = 0; // Remove newline character

    write(sockfd, filename, strlen(filename));

    int filefd = open(filename, O_WRONLY | O_CREAT | O_TRUNC, 0666);
    if (filefd < 0) {
        perror("Failed to open file");
        close(sockfd);
        return -1;
    }

    char buffer[BUFFER_SIZE];
    ssize_t bytes_read;

    while ((bytes_read = read(sockfd, buffer, sizeof(buffer))) > 0) {
        write(filefd, buffer, bytes_read);
    }

    if (bytes_read < 0) {
        perror("Failed to read from socket");
    } else {
        printf("File %s downloaded successfully.\n", filename);
    }

    close(filefd);
    close(sockfd);
    return 0;
}

