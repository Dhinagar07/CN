#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>

typedef struct {
    char method[8];
    char path[256];
    char version[16];
    char host[128];
    char headers[1024];
    char body[2048];
} HttpRequest;

typedef struct {
    char version[16];
    int status_code;
    char status_message[64];
    char headers[1024];
    char body[2048];
} HttpResponse;

#define BUFFER_SIZE 1024

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <server IP> <server port>\n", argv[0]);
        return -1;
    }

    const char *server_ip = argv[1];
    int server_port = atoi(argv[2]);

    int sock = 0;
    struct sockaddr_in serv_addr;
    HttpRequest request;
    HttpResponse response;

    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("Socket creation error");
        return -1;
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(server_port);

    if (inet_pton(AF_INET, server_ip, &serv_addr.sin_addr) <= 0) {
        perror("Invalid address/ Address not supported");
        close(sock);
        return -1;
    }

    if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
        perror("Connection Failed");
        close(sock);
        return -1;
    }

    strcpy(request.method, "GET");
    strcpy(request.path, "/");
    strcpy(request.version, "HTTP/1.1");
    strcpy(request.host, "localhost");

    send(sock, &request, sizeof(HttpRequest), 0);
    printf("Request sent\n");

    recv(sock, &response, sizeof(HttpResponse), 0);
    printf("Response received: %s %d %s\n%s\n%s\n",
           response.version, response.status_code, response.status_message,
           response.headers, response.body);

    close(sock);
    return 0;
}

