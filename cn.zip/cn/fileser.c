#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <fcntl.h>

#define BUFFER_SIZE 1024

void handle_client(int connfd) {
    char filename[BUFFER_SIZE];
    memset(filename, 0, sizeof(filename));

    int n = read(connfd, filename, sizeof(filename));
    if (n <= 0) {
        close(connfd);
        return;
    }

    filename[strcspn(filename, "\n")] = 0; // Remove newline character

    int filefd = open(filename, O_RDONLY);
    if (filefd < 0) {
        write(connfd, "File not found", strlen("File not found"));
    } else {
        char buffer[BUFFER_SIZE];
        ssize_t bytes_read;

        while ((bytes_read = read(filefd, buffer, sizeof(buffer))) > 0) {
            write(connfd, buffer, bytes_read);
        }

        close(filefd);
    }

    close(connfd);
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <port>\n", argv[0]);
        return -1;
    }

    int port = atoi(argv[1]);

    int sockdesc = socket(AF_INET, SOCK_STREAM, 0);
    if (sockdesc < 0) {
        perror("Failed to create socket");
        return -1;
    }

    struct sockaddr_in servaddr;
    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(port);
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);

    if (bind(sockdesc, (struct sockaddr*)&servaddr, sizeof(servaddr)) < 0) {
        perror("Bind failed");
        close(sockdesc);
        return -1;
    }

    if (listen(sockdesc, 5) < 0) {
        perror("Listen failed");
        close(sockdesc);
        return -1;
    }

    printf("Server listening on port %d\n", port);

    while (1) {
        struct sockaddr_in cliaddr;
        socklen_t len = sizeof(cliaddr);
        int connfd = accept(sockdesc, (struct sockaddr*)&cliaddr, &len);

        if (connfd < 0) {
            perror("Accept failed");
            continue;
        }

        if (fork() == 0) {
            close(sockdesc);
            handle_client(connfd);
            exit(0);
        }

        close(connfd);
    }

    close(sockdesc);
    return 0;
}

